# Local review interface

`review_server.py` offers a localhost-only page for reviewing a carousel directory produced by `render_carousel.py`. It does not send data to a service, upload, schedule, or publish. Start it from the pipeline directory:

```
python3 review_server.py /path/to/rendered-carousel --port 8765
```

Open `http://127.0.0.1:8765/` on the same computer. Review every slide, the caption and the source, then confirm the checkbox and record review. Press Ctrl+C to stop. You need permission to bind a local TCP port; some sandboxes disallow local server sockets. No extra packages are required for the reviewer.

Approval is saved once as `approval.json` in the rendered directory, and binds the exact manifest, caption, and ordered image bytes. A changed file invalidates the displayed approval digest; image requests are digest-bound. The record covers local content only—it is **not** approval for a destination, media URL, account, time, or act of publication. It does not verify copyright, source accuracy, semantic truth, or the identity of the human pressing the button. A separate publishing system must validate that reviewed content matches hosted media and bind any publication approval to its destination and timing. The current Buffer preview does not use or enforce this file.

An approval record is created once and never overwritten. If a file changes, create a fresh render directory and review the new files. Keep this directory private. The server binds to IPv4 loopback only, requires same-origin POST plus an unpredictable per-run CSRF token, checks host headers and rejects symbolic-link input files; it is not designed as a public-facing service. Don't use it on a shared untrusted machine or expose it using port-forwarding or a reverse proxy.
