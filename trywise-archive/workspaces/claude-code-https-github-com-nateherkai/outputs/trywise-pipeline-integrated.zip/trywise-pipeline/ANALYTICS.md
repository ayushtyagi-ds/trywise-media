# Metrics overview

`analytics.py` summarizes a user-provided CSV export. It doesn't connect to Instagram or fetch data. Required columns: `format,reach,saves,shares,profile_visits,post_follows` with nonnegative whole numbers. Only compare metrics measured over the same time window. Missing data must not be silently entered as zero. Summed per-post reach counts repeat viewers and does not establish unique account reach. Post-attributed follows are not net followers, and correlation is not causation. Account-level net follows should be tracked separately.

Example: `python3 analytics.py /path/to/metrics.csv`. API metrics retrieval and scheduled reporting remain unimplemented.
